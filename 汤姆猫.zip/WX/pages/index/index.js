// pages/index/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl:"../assets/Animations/Angry/angry_0.jpg",
    audioUrl:"",
    action:{
      method:""
    },disabled:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },cymbal(event){
    // 打锣
    var that = this;
    refreshAction(this,"cymbal",500,"Cymbal/cymbal_",12);
  },drink(event) {
    // 喝牛奶
    var that = this;
    that.setData({audioUrl:"../assets/audio/pour_milk.wav"});
    setTimeout(function(){
      that.setData({action:{
        method:"play"
      }
      });
    that.setData({audioUrl:"../assets/audio/p_drink_milk.wav"});
    },1800);
    setTimeout(function(){
      that.setData({action:{
        method:"play"
      }});
    },4000);
    var i = 0;
    var timer = setInterval(function(){
      that.setData({imgUrl:"../assets/Animations/Drink/drink_"+i+".jpg"});
      i++;
      if(i<=80){
        that.setData({disabled:true});
      }else if(i>80){
        clearInterval(timer);
        that.setData({disabled:false});
      }
    },100);
  },eat(event) {
    // 小鸟
    refreshAction(this, "p_eat", 1500, "Eat/eat_", 39);
  },fart(event) {
    // 放屁
    refreshAction(this, "fart001_11025", 500, "Fart/fart_", 27);
  },pie(event) {
    // 往窗户上扔饼
    refreshAction(this, "slap6", 1500, "Pie/pie_", 23);
  },scratch(event) {
    // 爪子挠屏幕
    refreshAction(this, "scratch_kratzen", 2200, "Scratch/scratch_", 55);
  },knockout(event) {
    // 打脸
    var that = this;
    that.setData({audioUrl:"../assets/audio/slap1.wav"});
    setTimeout(function(){
      that.setData({action:{
        method:"play"
      }});
      setTimeout(function(){
        refreshAction(that, "p_stars2s", 2000, "Knockout/knockout_", 80);
      },200);
    },50);
    refreshAction(this, "p_belly1", 200, "Stomach/stomach_", 12);
  },stomach(event) {
    // 摸肚子
    refreshAction(this, "p_belly1", 200, "Stomach/stomach_", 33);
  },footLeft(event) {
    // 打左脚
    refreshAction(this, "p_foot3", 200, "FootLeft/footLeft_", 29);
  },footRight(event) {
    // 打右脚
    refreshAction(this, "p_foot4", 200, "FootRight/footRight_", 29);
  },angry(event) {
    // 打尾巴
    refreshAction(this, "p_noo", 1100, "Angry/angry_", 25);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})

function refreshAction(that,audio,audioTime,path,imgSize){
  that.setData({ audioUrl: "../assets/audio/"+audio+".wav" });
  setTimeout(function () {
    that.setData({
      action: {
        method: "play"
      }
    });
  }, audioTime);
  //遍历图片
  var i = 0;
  var timer = setInterval(function () {
    that.setData({
      imgUrl: "../assets/Animations/"+path+i+".jpg"
    });
    i++;
    if (i <= imgSize) {
      that.setData({ disabled: true });
    } else if (i > imgSize) {
      clearInterval(timer);
      that.setData({ disabled: false });
    }
  }, 100);
}
